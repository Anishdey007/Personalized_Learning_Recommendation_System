"""
main.py
=======
Main terminal application entry point for the Personalized Learning Recommendation System.
Launches the interactive menu or executes CLI tasks for EDA and evaluation.
"""

import argparse
import sys
from pathlib import Path

# Ensure module imports work from workspace root
PROJECT_ROOT = Path(__file__).parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from cli import main_menu, run_eda_menu, run_evaluation_menu
from eda import EDAVisualizer
from evaluator import RecommenderEvaluator


def main():
    parser = argparse.ArgumentParser(
        description="Personalized Learning Recommendation System (BCA57205 - Machine Learning)"
    )
    parser.add_argument(
        "--eda", action="store_true", help="Generate all EDA visualization figures into outputs/figures/"
    )
    parser.add_argument(
        "--eval", action="store_true", help="Execute recommendation evaluation benchmark (Precision@K, MRR)"
    )

    args = parser.parse_args()

    if args.eda:
        print("[*] Running EDA visualizer...")
        visualizer = EDAVisualizer()
        paths = visualizer.generate_all_visualizations()
        print(f"[+] Successfully generated {len(paths)} visualization charts in outputs/figures/")
    elif args.eval:
        print("[*] Running recommendation evaluation...")
        evaluator = RecommenderEvaluator()
        metrics = evaluator.evaluate_cohort(k=5)
        print(f"[+] Evaluation complete: Precision@5={metrics['mean_precision_at_k']:.4f}, HitRate@5={metrics['hit_rate_at_k']:.4f}")
    else:
        # Launch interactive terminal application
        main_menu()


if __name__ == "__main__":
    main()
