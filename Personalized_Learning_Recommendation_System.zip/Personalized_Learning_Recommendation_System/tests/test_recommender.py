"""
test_recommender.py
===================
Unit and integration test suite for the Personalized Learning Recommendation System.
Validates dataset loading, profile boundary validation, completed topic filtering,
recommendation generation, ranking order, explainability, and error handling.
"""

import sys
import unittest
from pathlib import Path
import pandas as pd
import numpy as np

# Ensure parent directory is on sys.path for test runner
TEST_DIR = Path(__file__).parent
PROJECT_DIR = TEST_DIR.parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from data_loader import (
    DataLoader,
    StudentProfile,
    InvalidStudentProfileError,
    DatasetLoadError,
    VALID_LEVELS,
    VALID_STYLES,
)
from recommender import RecommendationEngine, recommend_resources
from evaluator import RecommenderEvaluator


class TestDataLoaderAndValidation(unittest.TestCase):
    """Tests for DataLoader, data cleaning, and student profile validation."""

    def setUp(self):
        self.loader = DataLoader(PROJECT_DIR / "data")

    def test_load_students_success(self):
        """Verify student dataset loads successfully with required columns."""
        df = self.loader.load_students()
        self.assertFalse(df.empty)
        expected_cols = [
            "student_id", "name", "interests", "preferred_style",
            "current_level", "math_score", "programming_score",
            "data_science_score", "study_hours_per_week", "completed_topics"
        ]
        for col in expected_cols:
            self.assertIn(col, df.columns)

    def test_load_resources_success(self):
        """Verify learning resources dataset loads successfully with required columns."""
        df = self.loader.load_resources()
        self.assertFalse(df.empty)
        expected_cols = ["resource_id", "title", "topic", "description", "resource_type", "difficulty", "url"]
        for col in expected_cols:
            self.assertIn(col, df.columns)

    def test_valid_student_profile(self):
        """Verify a properly configured profile validates without error."""
        profile = StudentProfile(
            student_id="VALID_01",
            name="Alice",
            interests="python, machine learning",
            preferred_style="video",
            current_level="beginner",
            math_score=85.0,
            programming_score=75.0,
            data_science_score=70.0,
            study_hours_per_week=10.0,
            completed_topics=["variables", "loops"]
        )
        # Should not raise exception
        profile.validate()
        self.assertAlmostEqual(profile.average_score, 76.6666, places=3)

    def test_negative_marks_raise_error(self):
        """Verify negative marks trigger an InvalidStudentProfileError."""
        profile = StudentProfile(
            student_id="INV_01",
            name="Bob",
            interests="python",
            math_score=-15.0,
        )
        with self.assertRaises(InvalidStudentProfileError):
            profile.validate()

    def test_marks_above_100_raise_error(self):
        """Verify marks exceeding 100 trigger an InvalidStudentProfileError."""
        profile = StudentProfile(
            student_id="INV_02",
            name="Charlie",
            interests="data science",
            programming_score=115.0,
        )
        with self.assertRaises(InvalidStudentProfileError):
            profile.validate()

    def test_negative_study_hours_raise_error(self):
        """Verify negative study hours trigger an InvalidStudentProfileError."""
        profile = StudentProfile(
            student_id="INV_03",
            name="Dana",
            interests="web development",
            study_hours_per_week=-5.0,
        )
        with self.assertRaises(InvalidStudentProfileError):
            profile.validate()

    def test_excessive_study_hours_raise_error(self):
        """Verify study hours beyond 80 hrs/wk trigger an InvalidStudentProfileError."""
        profile = StudentProfile(
            student_id="INV_04",
            name="Evan",
            interests="statistics",
            study_hours_per_week=105.0,
        )
        with self.assertRaises(InvalidStudentProfileError):
            profile.validate()

    def test_invalid_level_raise_error(self):
        """Verify unsupported proficiency level triggers error."""
        profile = StudentProfile(
            student_id="INV_05",
            name="Fiona",
            interests="ai",
            current_level="expert_master",
        )
        with self.assertRaises(InvalidStudentProfileError):
            profile.validate()

    def test_invalid_style_raise_error(self):
        """Verify unsupported learning style triggers error."""
        profile = StudentProfile(
            student_id="INV_06",
            name="George",
            interests="ai",
            preferred_style="telepathy",
        )
        with self.assertRaises(InvalidStudentProfileError):
            profile.validate()

    def test_missing_dataset_file_raises_error(self):
        """Verify attempting to load from non-existent directory raises DatasetLoadError."""
        bad_loader = DataLoader(PROJECT_DIR / "non_existent_folder")
        with self.assertRaises(DatasetLoadError):
            bad_loader.load_students()


class TestRecommendationEngine(unittest.TestCase):
    """Tests recommendation generation, ranking, filtering, and explainability."""

    def setUp(self):
        self.engine = RecommendationEngine()

    def test_recommendation_generation(self):
        """Verify recommendations are returned for a standard learner."""
        profile = {
            "name": "Test Learner",
            "interests": "machine learning, python",
            "preferred_style": "video",
            "current_level": "intermediate",
            "math_score": 70,
            "programming_score": 65,
            "data_science_score": 60,
            "study_hours_per_week": 14,
        }
        recs = self.engine.recommend(profile, top_n=5)
        self.assertEqual(len(recs), 5)
        self.assertIn("match_score", recs.columns)
        self.assertIn("recommendation_reason", recs.columns)

    def test_recommendation_ranking_order(self):
        """Verify that recommended resources are sorted in descending order of match_score."""
        profile = {
            "interests": "statistics, data science",
            "preferred_style": "reading",
            "current_level": "beginner",
        }
        recs = self.engine.recommend(profile, top_n=5)
        scores = recs["match_score"].tolist()
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_empty_interests_fallback(self):
        """Verify system handles empty interest string gracefully without crashing."""
        profile = {
            "interests": "",
            "preferred_style": "video",
            "current_level": "beginner",
        }
        recs = self.engine.recommend(profile, top_n=3)
        self.assertEqual(len(recs), 3)
        self.assertTrue(all(recs["match_score"] > 0))

    def test_completed_topics_excluded_when_not_revising(self):
        """Verify that completed topics are excluded from recommendations in standard mode."""
        profile = {
            "name": "Mastered Python Learner",
            "interests": "python, machine learning",
            "preferred_style": "video",
            "current_level": "beginner",
            "completed_topics": "python basics: variables and loops; python practice lab",
        }
        # Run with revision_mode=False (default)
        recs = self.engine.recommend(profile, top_n=5, revision_mode=False)
        rec_titles = [t.lower() for t in recs["title"].tolist()]

        self.assertNotIn("python basics: variables and loops", rec_titles)

    def test_completed_topics_included_when_revision_mode_enabled(self):
        """Verify that revision mode allows previously completed topics to be recommended."""
        profile = {
            "name": "Revising Learner",
            "interests": "python",
            "preferred_style": "video",
            "current_level": "beginner",
            "completed_topics": "python",
        }
        # With revision_mode=True, python resources should be allowed
        recs = self.engine.recommend(profile, top_n=5, revision_mode=True)
        rec_topics = [t.lower() for t in recs["topic"].tolist()]
        self.assertIn("python", rec_topics)

    def test_explainability_reason_present(self):
        """Verify each recommendation contains a non-empty pedagogical rationale."""
        profile = {
            "interests": "web development, javascript",
            "preferred_style": "hands-on",
            "current_level": "beginner",
            "programming_score": 50,
        }
        recs = self.engine.recommend(profile, top_n=3)
        for _, row in recs.iterrows():
            reason = row["recommendation_reason"]
            self.assertIsInstance(reason, str)
            self.assertGreater(len(reason), 10)


class TestRecommenderEvaluator(unittest.TestCase):
    """Tests the evaluation framework metrics."""

    def test_evaluator_metrics(self):
        evaluator = RecommenderEvaluator()
        metrics = evaluator.evaluate_cohort(k=5)

        self.assertIn("mean_precision_at_k", metrics)
        self.assertIn("hit_rate_at_k", metrics)
        self.assertIn("mean_reciprocal_rank", metrics)
        self.assertIn("catalog_coverage_pct", metrics)

        # Basic sanity bounds
        self.assertGreaterEqual(metrics["mean_precision_at_k"], 0.0)
        self.assertLessEqual(metrics["mean_precision_at_k"], 1.0)
        self.assertGreaterEqual(metrics["hit_rate_at_k"], 0.70)
        self.assertGreater(metrics["catalog_coverage_pct"], 50.0)


if __name__ == "__main__":
    unittest.main()
