"""
eda.py
======
Exploratory Data Analysis (EDA) and Visualization module for the
Personalized Learning Recommendation System.
Generates publication-quality charts using Pandas, NumPy, and Matplotlib.
"""

from pathlib import Path
from typing import Dict, Any, Optional
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend suitable for scripts and servers
import matplotlib.pyplot as plt

from data_loader import DataLoader

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
OUTPUTS_DIR = BASE_DIR / "outputs"
FIGURES_DIR = OUTPUTS_DIR / "figures"


class EDAVisualizer:
    """
    Handles generation of exploratory data analysis charts and summary metrics
    for student demographics, learning habits, performance, and resource catalog.
    """

    def __init__(self, data_dir: Optional[Path] = None, output_dir: Optional[Path] = None):
        self.data_loader = DataLoader(data_dir or DATA_DIR)
        self.output_dir = Path(output_dir or FIGURES_DIR)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.students_df = self.data_loader.load_students()
        self.resources_df = self.data_loader.load_resources()

    def get_summary_statistics(self) -> Dict[str, Any]:
        """
        Computes descriptive statistical metrics using NumPy and Pandas.
        """
        df = self.students_df
        stats = {
            "total_students": int(len(df)),
            "math_mean": float(np.mean(df["math_score"])),
            "math_std": float(np.std(df["math_score"])),
            "math_median": float(np.median(df["math_score"])),
            "programming_mean": float(np.mean(df["programming_score"])),
            "programming_std": float(np.std(df["programming_score"])),
            "programming_median": float(np.median(df["programming_score"])),
            "data_science_mean": float(np.mean(df["data_science_score"])),
            "data_science_std": float(np.std(df["data_science_score"])),
            "data_science_median": float(np.median(df["data_science_score"])),
            "study_hours_mean": float(np.mean(df["study_hours_per_week"])),
            "study_hours_std": float(np.std(df["study_hours_per_week"])),
            "study_hours_median": float(np.median(df["study_hours_per_week"])),
        }

        # Calculate Pearson correlation between study hours and average academic performance
        avg_scores = df[["math_score", "programming_score", "data_science_score"]].mean(axis=1)
        corr_matrix = np.corrcoef(df["study_hours_per_week"], avg_scores)
        stats["hours_performance_correlation"] = float(corr_matrix[0, 1])

        return stats

    def plot_marks_distribution(self, filename: str = "marks_distribution.png") -> Path:
        """
        Plot 1: Distribution of student marks across academic subjects.
        """
        df = self.students_df
        fig, axes = plt.subplots(1, 3, figsize=(15, 5), sharey=True)
        fig.suptitle("Academic Performance Distribution Across Subjects", fontsize=15, fontweight="bold")

        subjects = [
            ("math_score", "Mathematics", "#1f77b4"),
            ("programming_score", "Programming", "#2ca02c"),
            ("data_science_score", "Data Science", "#ff7f0e"),
        ]

        for ax, (col, title, color) in zip(axes, subjects):
            data = df[col].to_numpy()
            mean_val = float(np.mean(data))
            median_val = float(np.median(data))

            ax.hist(data, bins=8, color=color, alpha=0.75, edgecolor="black", density=False)
            ax.axvline(mean_val, color="red", linestyle="--", linewidth=1.5, label=f"Mean: {mean_val:.1f}")
            ax.axvline(median_val, color="black", linestyle=":", linewidth=1.5, label=f"Median: {median_val:.1f}")
            ax.set_title(f"{title} Marks", fontsize=12, fontweight="semibold")
            ax.set_xlabel("Score (0 - 100)")
            ax.set_ylabel("Student Count")
            ax.set_xlim(40, 100)
            ax.grid(axis="y", linestyle="--", alpha=0.5)
            ax.legend(loc="upper left")

        plt.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300)
        plt.close(fig)
        return save_path

    def plot_study_hours_vs_performance(self, filename: str = "study_hours_vs_performance.png") -> Path:
        """
        Plot 2: Scatter plot and trendline showing Study Hours vs Average Academic Performance.
        """
        df = self.students_df
        hours = df["study_hours_per_week"].to_numpy()
        avg_scores = df[["math_score", "programming_score", "data_science_score"]].mean(axis=1).to_numpy()

        # Compute regression trendline with NumPy polyfit
        slope, intercept = np.polyfit(hours, avg_scores, 1)
        trend_x = np.linspace(hours.min(), hours.max(), 50)
        trend_y = slope * trend_x + intercept

        # Pearson correlation coefficient
        corr = np.corrcoef(hours, avg_scores)[0, 1]

        fig, ax = plt.subplots(figsize=(8, 6))
        ax.scatter(hours, avg_scores, color="#3b528b", alpha=0.8, s=60, edgecolors="white", linewidth=0.8, label="Student")
        ax.plot(trend_x, trend_y, color="#e41a1c", linewidth=2, linestyle="-", label=f"Linear Fit (r = {corr:.2f})")

        ax.set_title("Study Hours per Week vs. Academic Performance", fontsize=14, fontweight="bold")
        ax.set_xlabel("Weekly Study Hours (hrs/wk)", fontsize=11)
        ax.set_ylabel("Average Score (Math, Prog, DS)", fontsize=11)
        ax.grid(True, linestyle="--", alpha=0.5)
        ax.legend(loc="lower right", fontsize=11)

        plt.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300)
        plt.close(fig)
        return save_path

    def plot_learning_style_distribution(self, filename: str = "learning_style_distribution.png") -> Path:
        """
        Plot 3: Distribution of learner preferred formats and proficiency levels.
        """
        df = self.students_df
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

        # Subplot 1: Preferred Style Bar Chart
        style_counts = df["preferred_style"].value_counts()
        colors1 = ["#4e79a7", "#f28e2b", "#e15759", "#76b7b2"]
        bars1 = ax1.bar(style_counts.index.str.capitalize(), style_counts.values, color=colors1[:len(style_counts)], edgecolor="black", alpha=0.85)
        ax1.set_title("Distribution of Preferred Learning Styles", fontsize=12, fontweight="bold")
        ax1.set_xlabel("Learning Modality")
        ax1.set_ylabel("Number of Students")
        ax1.grid(axis="y", linestyle="--", alpha=0.5)
        for bar in bars1:
            yval = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width() / 2, yval + 0.3, int(yval), ha="center", va="bottom", fontweight="bold")

        # Subplot 2: Proficiency Level Breakdown
        level_counts = df["current_level"].value_counts().reindex(["beginner", "intermediate", "advanced"]).fillna(0)
        colors2 = ["#59a14f", "#edc948", "#b07aa1"]
        bars2 = ax2.bar(level_counts.index.str.capitalize(), level_counts.values, color=colors2, edgecolor="black", alpha=0.85)
        ax2.set_title("Student Proficiency Level Distribution", fontsize=12, fontweight="bold")
        ax2.set_xlabel("Academic Proficiency Level")
        ax2.set_ylabel("Number of Students")
        ax2.grid(axis="y", linestyle="--", alpha=0.5)
        for bar in bars2:
            yval = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width() / 2, yval + 0.3, int(yval), ha="center", va="bottom", fontweight="bold")

        plt.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300)
        plt.close(fig)
        return save_path

    def plot_resource_catalog_breakdown(self, filename: str = "resource_catalog_breakdown.png") -> Path:
        """
        Plot 4: Distribution of catalog resources by topic and difficulty.
        """
        df = self.resources_df
        pivot_data = pd.crosstab(df["topic"], df["difficulty"])[["beginner", "intermediate", "advanced"]].fillna(0)

        fig, ax = plt.subplots(figsize=(10, 6))
        pivot_data.plot(
            kind="barh",
            stacked=True,
            ax=ax,
            color=["#72b7b2", "#f28e2b", "#e15759"],
            edgecolor="black",
            alpha=0.85,
        )

        ax.set_title("Learning Resources Catalog: Topics by Difficulty Level", fontsize=14, fontweight="bold")
        ax.set_xlabel("Resource Count", fontsize=11)
        ax.set_ylabel("Topic Domain", fontsize=11)
        ax.legend(title="Difficulty Level", labels=["Beginner", "Intermediate", "Advanced"], loc="lower right")
        ax.grid(axis="x", linestyle="--", alpha=0.5)

        plt.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300)
        plt.close(fig)
        return save_path

    def plot_recommendation_score_breakdown(
        self, recs_df: pd.DataFrame, filename: str = "recommendation_score_breakdown.png"
    ) -> Path:
        """
        Plot 5: Stacked horizontal bar chart showing multi-factor score breakdown
        (Text similarity, difficulty match, style match, skill boost) for recommended resources.
        """
        fig, ax = plt.subplots(figsize=(10, 5))
        titles = [t[:32] + "..." if len(t) > 35 else t for t in recs_df["title"]][::-1]

        # Weights from engine
        w_text, w_diff, w_style, w_skill = 0.55, 0.20, 0.15, 0.10

        c_text = (recs_df["text_similarity"] * w_text).to_numpy()[::-1]
        c_diff = (recs_df["difficulty_score"] * w_diff).to_numpy()[::-1]
        c_style = (recs_df["style_score"] * w_style).to_numpy()[::-1]
        c_skill = (recs_df["skill_boost"] * w_skill).to_numpy()[::-1]

        ax.barh(titles, c_text, label="Text Match (55%)", color="#4e79a7", edgecolor="black", alpha=0.85)
        ax.barh(titles, c_diff, left=c_text, label="Difficulty Match (20%)", color="#59a14f", edgecolor="black", alpha=0.85)
        ax.barh(titles, c_style, left=c_text + c_diff, label="Format Match (15%)", color="#f28e2b", edgecolor="black", alpha=0.85)
        ax.barh(titles, c_skill, left=c_text + c_diff + c_style, label="Weak-Area Boost (10%)", color="#e15759", edgecolor="black", alpha=0.85)

        ax.set_title("Explainable Recommendation Score Contribution Breakdown", fontsize=13, fontweight="bold")
        ax.set_xlabel("Composite Match Score", fontsize=11)
        ax.set_xlim(0, 1.0)
        ax.legend(loc="lower right")
        ax.grid(axis="x", linestyle="--", alpha=0.5)

        plt.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300)
        plt.close(fig)
        return save_path

    def generate_all_visualizations(self) -> Dict[str, Path]:
        """Runs all visualization routines and returns dictionary of saved paths."""
        saved_paths = {
            "marks_distribution": self.plot_marks_distribution(),
            "study_hours_vs_performance": self.plot_study_hours_vs_performance(),
            "learning_style_distribution": self.plot_learning_style_distribution(),
            "resource_catalog_breakdown": self.plot_resource_catalog_breakdown(),
        }
        return saved_paths


if __name__ == "__main__":
    visualizer = EDAVisualizer()
    stats = visualizer.get_summary_statistics()
    print("--- DATASET SUMMARY STATISTICS ---")
    for k, v in stats.items():
        print(f"  {k}: {v:.2f}" if isinstance(v, float) else f"  {k}: {v}")

    paths = visualizer.generate_all_visualizations()
    print("\n--- GENERATED CHARTS ---")
    for name, p in paths.items():
        print(f"  [+] {name}: {p}")
