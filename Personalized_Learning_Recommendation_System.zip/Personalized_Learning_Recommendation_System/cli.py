"""
cli.py
======
Interactive Terminal Interface for the Personalized Learning Recommendation System.
Provides student learning input, validation, explainable recommendations,
Exploratory Data Analysis (EDA), and model evaluation.
"""

from pathlib import Path
from typing import Dict, Any, Optional
import pandas as pd

from data_loader import DataLoader, StudentProfile, InvalidStudentProfileError, VALID_LEVELS, VALID_STYLES
from recommender import RecommendationEngine
from eda import EDAVisualizer
from evaluator import RecommenderEvaluator

DATA_DIR = Path(__file__).parent / "data"
OUTPUTS_DIR = Path(__file__).parent / "outputs"


def clear_banner():
    print("\n" + "=" * 76)
    print("      GRADUATION PROJECT: PERSONALIZED LEARNING RECOMMENDATION SYSTEM      ")
    print("                     BCA57205 - Machine Learning (GR-1)                     ")
    print("=" * 76)


def get_float_input(prompt: str, default: float, min_val: float = 0.0, max_val: float = 100.0) -> float:
    """Safely prompts for a float value with boundary validation and default fallback."""
    while True:
        raw = input(f"{prompt} [{default}]: ").strip()
        if not raw:
            return default
        try:
            val = float(raw)
            if min_val <= val <= max_val:
                return val
            print(f"  [!] Please enter a value between {min_val} and {max_val}.")
        except ValueError:
            print("  [!] Invalid numeric format. Please enter a valid number.")


def get_choice_input(prompt: str, valid_options: tuple, default: str) -> str:
    """Prompts for one of the valid categorical options."""
    opts_str = "/".join(valid_options)
    while True:
        raw = input(f"{prompt} ({opts_str}) [{default}]: ").strip().lower()
        if not raw:
            return default
        if raw in valid_options:
            return raw
        print(f"  [!] Invalid choice. Valid options are: {', '.join(valid_options)}")


def display_recommendations(recs: pd.DataFrame, student_name: str, show_reasons: bool = True):
    """Prints ranked recommendations with clean formatting and pedagogical rationale."""
    if recs.empty:
        print("\n[!] No matching learning resources found for the given criteria.")
        return

    print("\n" + "=" * 76)
    print(f"     PERSONALIZED LEARNING RECOMMENDATIONS FOR: {student_name.upper()}")
    print("=" * 76)

    for idx, (_, row) in enumerate(recs.iterrows(), start=1):
        print(f"\n{idx}. {row['title']}")
        print(f"   Topic       : {row['topic'].capitalize()} | Difficulty: {row['difficulty'].capitalize()} | Format: {row['resource_type'].capitalize()}")
        print(f"   Match Score : {row['match_score']:.4f} (Text: {row['text_similarity']:.2f}, Diff: {row['difficulty_score']:.2f}, Format: {row['style_score']:.2f}, Boost: {row['skill_boost']:.2f})")
        print(f"   Description : {row['description']}")
        print(f"   Resource URL: {row['url']}")
        if show_reasons and "recommendation_reason" in row:
            print(f"   Why Chosen  : {row['recommendation_reason']}")

    print("\n" + "=" * 76)


def export_recommendations_to_file(recs: pd.DataFrame, student: StudentProfile, filename: str = "recommendation_report.txt") -> Path:
    """Exports the generated recommendations and reasons to a formatted text file."""
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    report_path = OUTPUTS_DIR / filename
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("=" * 76 + "\n")
        f.write("          STUDENT LEARNING RECOMMENDATION REPORT\n")
        f.write("=" * 76 + "\n\n")
        f.write(f"Student Name     : {student.name}\n")
        f.write(f"Interests        : {student.interests}\n")
        f.write(f"Proficiency Level: {student.current_level}\n")
        f.write(f"Preferred Format : {student.preferred_style}\n")
        f.write(f"Study Hours/Week : {student.study_hours_per_week} hrs\n")
        f.write(f"Completed Topics : {', '.join(student.completed_topics) if student.completed_topics else 'None'}\n")
        f.write(f"Academic Scores  : Math: {student.math_score}, Programming: {student.programming_score}, Data Science: {student.data_science_score}\n\n")
        f.write("-" * 76 + "\n")
        f.write("RANKED LEARNING RESOURCES\n")
        f.write("-" * 76 + "\n\n")

        for idx, (_, row) in enumerate(recs.iterrows(), start=1):
            f.write(f"{idx}. {row['title']}\n")
            f.write(f"   Topic       : {row['topic'].capitalize()} | Level: {row['difficulty'].capitalize()} | Format: {row['resource_type'].capitalize()}\n")
            f.write(f"   Match Score : {row['match_score']:.4f}\n")
            f.write(f"   Description : {row['description']}\n")
            f.write(f"   URL         : {row['url']}\n")
            f.write(f"   Why Chosen  : {row.get('recommendation_reason', 'N/A')}\n\n")

    return report_path


def interactive_student_recommendations(engine: RecommendationEngine):
    """Workflow to enter student learning preferences with real-time input validation."""
    print("\n--- Enter Student Learning Information ---")
    name = input("Enter student name [Guest Learner]: ").strip() or "Guest Learner"
    interests = input("Enter learning interests (comma-separated, e.g. python, machine learning): ").strip()
    if not interests:
        interests = "python, machine learning"

    level = get_choice_input("Current proficiency level", VALID_LEVELS, default="beginner")
    style = get_choice_input("Preferred learning format", VALID_STYLES, default="video")

    math_s = get_float_input("Mathematics score (0-100)", default=70.0, min_val=0.0, max_val=100.0)
    prog_s = get_float_input("Programming score (0-100)", default=70.0, min_val=0.0, max_val=100.0)
    ds_s = get_float_input("Data Science score (0-100)", default=70.0, min_val=0.0, max_val=100.0)
    study_hrs = get_float_input("Weekly study hours (0-80)", default=12.0, min_val=0.0, max_val=80.0)

    completed = input("Completed topics to filter out (semicolon or comma-separated, or press Enter): ").strip()

    profile = StudentProfile(
        student_id="STUDENT_01",
        name=name,
        interests=interests,
        preferred_style=style,
        current_level=level,
        math_score=math_s,
        programming_score=prog_s,
        data_science_score=ds_s,
        study_hours_per_week=study_hrs,
        completed_topics=completed,
    )

    rev_choice = input("\nInclude already completed topics for revision? (y/n) [default: n]: ").strip().lower()
    revision_mode = (rev_choice == "y")

    top_k = int(get_float_input("Number of recommendations to display", default=5, min_val=1, max_val=15))

    recs = engine.recommend(profile, top_n=top_k, revision_mode=revision_mode)
    display_recommendations(recs, profile.name)

    exp_choice = input("Export this recommendation report to a file? (y/n) [default: y]: ").strip().lower()
    if exp_choice != "n":
        saved_file = export_recommendations_to_file(recs, profile, "custom_recommendation_report.txt")
        print(f"[+] Report exported successfully to: {saved_file}")


def run_eda_menu():
    """Generates and summarizes exploratory data analysis."""
    print("\n--- Running Exploratory Data Analysis (EDA) ---")
    visualizer = EDAVisualizer()
    stats = visualizer.get_summary_statistics()

    print("\nDataset Summary Statistics:")
    print(f"  * Total Enrolled Students      : {stats['total_students']}")
    print(f"  * Mean Weekly Study Hours      : {stats['study_hours_mean']:.1f} hrs (Std: {stats['study_hours_std']:.1f})")
    print(f"  * Math Score Mean / Median     : {stats['math_mean']:.1f} / {stats['math_median']:.1f}")
    print(f"  * Programming Score Mean/Median: {stats['programming_mean']:.1f} / {stats['programming_median']:.1f}")
    print(f"  * Data Science Score Mean/Med  : {stats['data_science_mean']:.1f} / {stats['data_science_median']:.1f}")
    print(f"  * Hours-Performance Correlation: r = {stats['hours_performance_correlation']:.2f}")

    print("\nGenerating Matplotlib Figures into outputs/figures/ ...")
    paths = visualizer.generate_all_visualizations()
    for name, p in paths.items():
        print(f"  [+] Saved {name}: {p.name}")
    print("\n[+] All charts generated successfully in the 'outputs/figures' folder.")


def run_evaluation_menu():
    """Runs recommendation evaluation benchmarks."""
    print("\n--- Running Model Evaluation Benchmark ---")
    evaluator = RecommenderEvaluator()
    top_k = int(get_float_input("Evaluation Top-K", default=5, min_val=1, max_val=10))
    print(f"Evaluating across all {len(evaluator.students_df)} students...")
    metrics = evaluator.evaluate_cohort(k=top_k, revision_mode=False)

    print("\nBenchmark Evaluation Results:")
    print(f"  * Cohort Size                    : {metrics['cohort_size']} students")
    print(f"  * Precision@{top_k}                   : {metrics['mean_precision_at_k']:.4f} ({metrics['mean_precision_at_k']*100:.1f}%)")
    print(f"  * Hit Rate@{top_k} (HR@{top_k})            : {metrics['hit_rate_at_k']:.4f} ({metrics['hit_rate_at_k']*100:.1f}%)")
    print(f"  * Mean Reciprocal Rank (MRR)     : {metrics['mean_reciprocal_rank']:.4f}")
    print(f"  * Catalog Coverage               : {metrics['catalog_coverage_pct']:.2f}% ({metrics['unique_resources_recommended']}/{metrics['total_catalog_resources']} items)")
    print(f"  * Completed Exclusion Accuracy   : {metrics['completed_topic_exclusion_rate_pct']:.2f}%")


def main_menu():
    """Main interactive terminal loop matching teacher requirements."""
    clear_banner()
    engine = RecommendationEngine()

    while True:
        print("\nMAIN MENU:")
        print("  1. Enter student learning information & get personalized recommendations")
        print("  2. Run Exploratory Data Analysis (EDA) & generate graphs")
        print("  3. Run recommendation model evaluation")
        print("  4. Exit")

        choice = input("\nEnter choice (1-4) [default: 1]: ").strip()
        if not choice:
            choice = "1"

        try:
            if choice == "1":
                interactive_student_recommendations(engine)
            elif choice == "2":
                run_eda_menu()
            elif choice == "3":
                run_evaluation_menu()
            elif choice == "4":
                print("\nThank you for using the Personalized Learning Recommendation System. Goodbye!")
                break
            else:
                print("  [!] Invalid menu choice. Please select 1, 2, 3, or 4.")
        except Exception as e:
            print(f"\n[!] An error occurred: {e}")
            print("    Returning to main menu cleanly.")


if __name__ == "__main__":
    main_menu()
