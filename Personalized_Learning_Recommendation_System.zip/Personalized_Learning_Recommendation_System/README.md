# Personalized Learning Recommendation System (PLRS)

**Course:** Machine Learning (BCA57205)  
**Group:** GR-1  
**Interface:** Python Terminal Application  
**Development Environment:** Python using Visual Studio Code  

An explainable content-based recommendation system that personalizes educational resource discovery according to student interests, proficiency levels, learning modalities, academic gaps, and study availability.

---

## Key Features
- **Semantic Text Matching:** Uses Scikit-Learn TF-IDF vectorization and Cosine Similarity to identify materials matching learner interests.
- **Pedagogical Difficulty Calibration:** Aligns resources to learner levels (Beginner, Intermediate, Advanced) with distance-based grading.
- **Learning Modality Compatibility:** Supports preferences across Video, Hands-on exercises, Reading, and Quizzes.
- **Academic Gap Reinforcement:** Dynamically boosts resources in subject areas where prior performance indicates a learning gap.
- **Completed Topic Non-Redundancy:** Filters out concepts already mastered by the learner, with an optional revision mode.
- **Explainable AI (XAI):** Provides transparent human-readable explanations ("Why Chosen") for every recommended resource.
- **Exploratory Data Analysis (EDA):** Generates publication-ready Matplotlib plots analyzing score distributions, study hours correlation, and catalog coverage in `outputs/figures/`.
- **Comprehensive Evaluation:** Offline benchmarking measuring Precision@K, Hit Rate@K, MRR, and Catalog Coverage across 50 student profiles.
- **Robust Error Handling:** Validates marks (0–100), weekly hours (0–80), and categorical inputs without application crashes.
- **Pure Terminal Application:** Interactive console interface designed for terminal grading and demonstration without extra web frameworks.

---

## Directory Structure
```
Personalized_Learning_Recommendation_System/
├── main.py                                      # Main entry point & CLI flags
├── cli.py                                       # Interactive terminal interface
├── recommender.py                               # Core Recommendation Engine & scoring logic
├── data_loader.py                               # Data loading, validation & OOP models
├── eda.py                                       # Exploratory Data Analysis & Matplotlib plotting
├── evaluator.py                                 # Recommender offline evaluation metrics
├── requirements.txt                             # Dependencies specification
├── README.md                                    # Project documentation
├── PROJECT_REPORT.md                            # Academic project report (all 18 sections)
├── data/
│   ├── students.csv                             # 50 student profiles
│   └── learning_resources.csv                   # 26 curated learning resources
├── outputs/
│   ├── figures/                                 # Generated EDA visualization charts (.png)
│   │   ├── marks_distribution.png
│   │   ├── study_hours_vs_performance.png
│   │   ├── learning_style_distribution.png
│   │   └── resource_catalog_breakdown.png
│   └── recommendation_report.txt                # Exported recommendation reports
└── tests/
    └── test_recommender.py                      # 17 automated unit tests (unittest)
```

---

## Setup and Installation

### 1. Requirements
- Python 3.10 or later
- Visual Studio Code

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

---

## How to Run in Visual Studio Code

### Option A: Interactive Command-Line Interface (Recommended)
Open a terminal in the project directory and run:
```bash
python main.py
```
This launches the simplified 4-option interactive menu:
1. Enter student learning information & get personalized recommendations
2. Run Exploratory Data Analysis (EDA) & generate charts
3. Run recommendation model evaluation metrics
4. Exit

### Option B: Command-Line Flags
- **Generate EDA Visualization Charts:**
  ```bash
  python main.py --eda
  ```
- **Run Model Evaluation Benchmark:**
  ```bash
  python main.py --eval
  ```

### Option C: Run Unit Tests
Execute the automated test suite covering 17 test cases:
```bash
python -m unittest tests/test_recommender.py
```

---

## Recommendation Methodology

The composite match score is computed as:
$$\text{Match Score} = 0.55 \times S_{\text{text}} + 0.20 \times S_{\text{diff}} + 0.15 \times S_{\text{style}} + 0.10 \times S_{\text{skill}} + \text{Feasibility Boost}$$

1. **$S_{\text{text}}$ (Text Similarity):** Cosine similarity between student interests TF-IDF vector and resource metadata.
2. **$S_{\text{diff}}$ (Difficulty Alignment):** 1.0 (exact match), 0.60 (1-step distance), 0.20 (2-step distance).
3. **$S_{\text{style}}$ (Modality Alignment):** 1.0 if resource format matches preferred format, else 0.35.
4. **$S_{\text{skill}}$ (Weak-Area Reinforcement):** Inversely proportional to student score in that subject domain: $(100 - \text{Score}) / 100$.
5. **Feasibility Boost:** $+0.05$ for bite-sized formats (quiz/video) if student study hours $< 8$ hrs/week.
6. **Completed Topics Filter:** Excludes mastered concepts unless revision mode is explicitly chosen.

---

## Actual Evaluation Benchmark Results (Cohort $N = 50$, Top-$K = 5$)
- **Precision@5:** 56.80% (top recommendations directly match interests and proficiency)
- **Hit Rate@5 (HR@5):** 98.00% (98% of students receive at least one highly relevant resource)
- **Mean Reciprocal Rank (MRR):** 0.8757 (first relevant item appears on average at rank 1.14)
- **Catalog Coverage:** 100.00% (26 of 26 catalog resources are discoverable)
- **Completed Topic Exclusion Rate:** 100.00% (zero completed topics recommended when revision mode is disabled)

---

## Academic Report
For full details, algorithms, flowchart, pseudocode, and contribution template, refer to [`PROJECT_REPORT.md`](file:///C:/Users/harbh/Downloads/Personalized_Learning_Recommendation_System/PROJECT_REPORT.md).
