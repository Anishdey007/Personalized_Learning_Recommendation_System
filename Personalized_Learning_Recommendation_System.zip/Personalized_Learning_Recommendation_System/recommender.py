"""
recommender.py
==============
Recommendation Engine for Personalized Learning Recommendation System.
Implements Content-Based Filtering using TF-IDF Text Vectorization, Cosine Similarity,
Pedagogical Difficulty Calibration, Learning Modality Alignment, Weak-Area Reinforcement,
Completed-Topics Filtering, and Explainable AI (XAI) rationale generation.
"""

from pathlib import Path
import re
from typing import Dict, List, Optional, Tuple, Any, Union
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from data_loader import DataLoader, StudentProfile, LearningResource

DATA_DIR = Path(__file__).parent / "data"


def normalise_text(value: Any) -> str:
    """Helper function to clean, lowercase and normalize whitespace in text strings."""
    return re.sub(r"\s+", " ", str(value or "").lower()).strip()


class RecommendationEngine:
    """
    Core Recommendation Engine.
    Combines text content similarity with learner-centric heuristics:
    1. Content Relevance (TF-IDF + Cosine Similarity)
    2. Difficulty Appropriateness (Pedagogical step distance)
    3. Format / Modality Compatibility (Video, hands-on, reading, quiz)
    4. Academic Reinforcement Boost (Targeting weaker subject areas)
    5. Study Hours Feasibility Factor (Adjusting for available weekly hours)
    6. Completed Topic Filtering (Ensuring novel learning vs revision)
    """

    # Weights for the composite score calculation
    DEFAULT_WEIGHTS = {
        "text": 0.55,
        "difficulty": 0.20,
        "style": 0.15,
        "skill": 0.10,
    }

    LEVEL_ORDER = ["beginner", "intermediate", "advanced"]

    def __init__(
        self,
        resources_df: Optional[pd.DataFrame] = None,
        weights: Optional[Dict[str, float]] = None,
    ):
        self.loader = DataLoader(DATA_DIR)
        if resources_df is None:
            self.resources_df = self.loader.load_resources()
        else:
            self.resources_df = resources_df.copy()

        self.weights = weights or self.DEFAULT_WEIGHTS.copy()
        self._vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self._fit_resource_corpus()

    def _fit_resource_corpus(self) -> None:
        """Precomputes text corpus for all catalog resources."""
        self.resource_texts = (
            self.resources_df["topic"].fillna("").astype(str) + " " +
            self.resources_df["title"].fillna("").astype(str) + " " +
            self.resources_df["description"].fillna("").astype(str)
        ).map(normalise_text).tolist()

    def _compute_text_similarity(self, query_text: str) -> np.ndarray:
        """
        Computes cosine similarity between learner query vector and all resources.
        Returns a 1D NumPy array of similarity scores in [0.0, 1.0].
        """
        cleaned_query = normalise_text(query_text).replace(",", " ")
        if not cleaned_query:
            # If query is completely empty, assign a neutral default similarity
            return np.full(len(self.resources_df), 0.15, dtype=float)

        full_corpus = self.resource_texts + [cleaned_query]
        tfidf_matrix = self._vectorizer.fit_transform(full_corpus)

        # Query vector is the last row; resource vectors are all preceding rows
        query_vec = tfidf_matrix[-1]
        catalog_vecs = tfidf_matrix[:-1]

        sim_matrix = cosine_similarity(query_vec, catalog_vecs)
        return sim_matrix.ravel()

    def _compute_difficulty_scores(self, student_level: str) -> np.ndarray:
        """
        Scores difficulty alignment using distance on the pedagogical ladder:
        Same level -> 1.0
        1 step difference (e.g. beginner -> intermediate) -> 0.60
        2 steps difference (e.g. beginner -> advanced) -> 0.20
        """
        norm_level = normalise_text(student_level)
        scores = []
        for res_diff in self.resources_df["difficulty"].map(normalise_text):
            if norm_level in self.LEVEL_ORDER and res_diff in self.LEVEL_ORDER:
                dist = abs(self.LEVEL_ORDER.index(norm_level) - self.LEVEL_ORDER.index(res_diff))
                step_score = {0: 1.0, 1: 0.60, 2: 0.20}.get(dist, 0.30)
            else:
                step_score = 0.50
            scores.append(step_score)
        return np.array(scores, dtype=float)

    def _compute_style_scores(self, preferred_style: str) -> np.ndarray:
        """
        Evaluates format alignment: 1.0 if matching learner preferred style, else 0.35.
        """
        norm_style = normalise_text(preferred_style)
        scores = [
            1.0 if normalise_text(t) == norm_style else 0.35
            for t in self.resources_df["resource_type"]
        ]
        return np.array(scores, dtype=float)

    def _compute_skill_boosts(self, math: float, prog: float, ds: float) -> np.ndarray:
        """
        Reinforcement learning incentive: assigns higher boost to topics where
        the student has lower prior performance (identifying learning gaps).
        """
        boosts = []
        for topic in self.resources_df["topic"].map(normalise_text):
            boost = 0.0
            if any(k in topic for k in ["python", "web development", "databases", "programming"]):
                boost = (100.0 - prog) / 100.0
            elif any(k in topic for k in ["machine learning", "mathematics", "statistics", "ai"]):
                boost = (100.0 - math) / 100.0
            elif any(k in topic for k in ["data science", "data visualization", "analytics"]):
                boost = (100.0 - ds) / 100.0
            else:
                boost = 0.30
            # Clip between 0 and 1
            boosts.append(np.clip(boost, 0.0, 1.0))
        return np.array(boosts, dtype=float)

    def _is_completed(self, resource_row: pd.Series, completed_topics: List[str]) -> bool:
        """
        Checks whether a candidate resource covers topics already mastered by student.
        """
        if not completed_topics:
            return False

        res_topic = normalise_text(resource_row["topic"])
        res_title = normalise_text(resource_row["title"])

        for comp in completed_topics:
            c = normalise_text(comp)
            if not c:
                continue
            # If the completed topic keyword appears in topic or title
            if c in res_topic or c in res_title or res_topic in c:
                return True
        return False

    def recommend(
        self,
        student: Union[StudentProfile, Dict[str, Any]],
        top_n: int = 5,
        revision_mode: bool = False,
    ) -> pd.DataFrame:
        """
        Generates ranked recommendations for the given student profile.

        Parameters:
        -----------
        student : StudentProfile or dict
            The profile containing student interests, scores, level, style, etc.
        top_n : int
            Number of recommendations to return (default: 5).
        revision_mode : bool
            If False (default), excludes topics already completed by the student.
            If True, allows reviewing previously completed topics.

        Returns:
        --------
        pd.DataFrame
            Ranked resources containing match score and explainability fields.
        """
        if isinstance(student, dict):
            profile = StudentProfile.from_dict(student)
        else:
            profile = student

        # Validate profile fields
        profile.validate()

        # 1. Feature scoring using NumPy
        text_sim = self._compute_text_similarity(profile.interests)
        diff_scores = self._compute_difficulty_scores(profile.current_level)
        style_scores = self._compute_style_scores(profile.preferred_style)
        skill_boost = self._compute_skill_boosts(
            profile.math_score, profile.programming_score, profile.data_science_score
        )

        # Optional workload feasibility adjustment:
        # If student has low weekly study hours (<8h), give a slight boost to quick-learning formats
        feasibility_adj = np.zeros(len(self.resources_df))
        if profile.study_hours_per_week < 8.0:
            for i, r_type in enumerate(self.resources_df["resource_type"].map(normalise_text)):
                if r_type in ["quiz", "video"]:
                    feasibility_adj[i] = 0.05

        # 2. Composite Match Score Formula
        w = self.weights
        composite_score = (
            w["text"] * text_sim +
            w["difficulty"] * diff_scores +
            w["style"] * style_scores +
            w["skill"] * skill_boost +
            feasibility_adj
        )

        candidates = self.resources_df.copy()
        candidates["text_similarity"] = np.round(text_sim, 4)
        candidates["difficulty_score"] = np.round(diff_scores, 4)
        candidates["style_score"] = np.round(style_scores, 4)
        candidates["skill_boost"] = np.round(skill_boost, 4)
        candidates["match_score"] = np.round(composite_score, 4)

        # 3. Filter completed topics unless revision mode is requested
        if not revision_mode and profile.completed_topics:
            mask = [
                not self._is_completed(row, profile.completed_topics)
                for _, row in candidates.iterrows()
            ]
            candidates = candidates[mask].copy()

        # If filtering removed all resources or candidates is empty, fall back gracefully
        if candidates.empty:
            # Fall back to un-filtered catalog so student is never left empty-handed
            candidates = self.resources_df.copy()
            candidates["text_similarity"] = np.round(text_sim, 4)
            candidates["difficulty_score"] = np.round(diff_scores, 4)
            candidates["style_score"] = np.round(style_scores, 4)
            candidates["skill_boost"] = np.round(skill_boost, 4)
            candidates["match_score"] = np.round(composite_score, 4)

        # 4. Sorting & Top-N Selection (Python multi-key ranking)
        sorted_recs = candidates.sort_values(
            by=["match_score", "text_similarity", "difficulty_score"],
            ascending=[False, False, False]
        ).head(int(top_n)).reset_index(drop=True)

        # 5. Generate transparent pedagogical explanations (XAI)
        explanations = []
        for _, row in sorted_recs.iterrows():
            reasons = []

            # Text relevance reason
            if row["text_similarity"] >= 0.35:
                reasons.append(f"Strong topic match with your interests in '{profile.interests}' ({row['text_similarity'] * 100:.1f}% similarity)")
            elif row["text_similarity"] > 0.10:
                reasons.append(f"Related to your specified interest areas ({row['text_similarity'] * 100:.1f}% similarity)")
            else:
                reasons.append("Broad foundational topic to expand your learning breadth")

            # Style reason
            if normalise_text(row["resource_type"]) == normalise_text(profile.preferred_style):
                reasons.append(f"Delivered in your preferred format ({row['resource_type']})")

            # Difficulty reason
            if normalise_text(row["difficulty"]) == normalise_text(profile.current_level):
                reasons.append(f"Targeted at your current proficiency level ({row['difficulty']})")
            else:
                reasons.append(f"Gentle progression towards {row['difficulty']} level")

            # Skill gap reason
            if row["skill_boost"] >= 0.35:
                reasons.append(f"Addresses identified growth area in {row['topic'].capitalize()}")

            # Study hours reason
            if profile.study_hours_per_week < 8.0 and row["resource_type"] in ["quiz", "video"]:
                reasons.append(f"Bite-sized resource fitting your limited weekly schedule ({profile.study_hours_per_week}h/wk)")

            explanations.append(" | ".join(reasons))

        sorted_recs["recommendation_reason"] = explanations
        return sorted_recs


# Top-level functional helper for backwards compatibility
def recommend_resources(
    profile: Union[Dict[str, Any], StudentProfile],
    top_n: int = 5,
    resources: Optional[pd.DataFrame] = None,
    revision_mode: bool = False,
) -> pd.DataFrame:
    """
    Standard interface to obtain recommendations.
    Maintains compatibility with existing scripts.
    """
    engine = RecommendationEngine(resources_df=resources)
    return engine.recommend(profile, top_n=top_n, revision_mode=revision_mode)


if __name__ == "__main__":
    sample_profile = {
        "student_id": "TEST_001",
        "name": "Sample Learner",
        "interests": "python, machine learning, data science",
        "preferred_style": "video",
        "current_level": "beginner",
        "math_score": 70,
        "programming_score": 60,
        "data_science_score": 55,
        "study_hours_per_week": 12,
        "completed_topics": "python syntax;basic loops",
    }
    recs = recommend_resources(sample_profile, top_n=5)
    print("\n--- SAMPLE RECOMMENDATIONS ---")
    for i, (_, row) in enumerate(recs.iterrows(), 1):
        print(f"\n{i}. {row['title']} [{row['topic']}]")
        print(f"   Match Score: {row['match_score']} | Diff: {row['difficulty']} | Type: {row['resource_type']}")
        print(f"   Reason: {row['recommendation_reason']}")
