"""
evaluator.py
============
Evaluation module for the Personalized Learning Recommendation System.
Computes standard information retrieval and recommendation metrics:
- Precision@K
- Hit Rate@K (HR@K)
- Mean Reciprocal Rank (MRR)
- Catalog Coverage
- Novelty / Completed-Topic Exclusion Rate
"""

from pathlib import Path
from typing import Dict, List, Any, Optional
import numpy as np
import pandas as pd

from data_loader import DataLoader, StudentProfile
from recommender import RecommendationEngine, normalise_text

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"


class RecommenderEvaluator:
    """
    Evaluates recommendation quality across student cohorts.
    Ground-truth relevance is assessed through semantic topic overlap with student interests,
    difficulty proximity, and absence of completed items.
    """

    def __init__(self, data_dir: Optional[Path] = None):
        self.loader = DataLoader(data_dir or DATA_DIR)
        self.students_df = self.loader.load_students()
        self.resources_df = self.loader.load_resources()
        self.engine = RecommendationEngine(resources_df=self.resources_df)

    def is_item_relevant(self, student: StudentProfile, item_row: pd.Series) -> bool:
        """
        Determines if a catalog item is relevant to the student.
        Relevance criteria:
        1. Interest overlap: The resource topic or title intersects with student's stated interests.
        2. Level proximity: The difficulty is within 1 step of student's current proficiency level.
        """
        student_interests = [
            t.strip() for t in normalise_text(student.interests).replace(";", ",").split(",") if t.strip()
        ]
        res_topic = normalise_text(item_row["topic"])
        res_title = normalise_text(item_row["title"])

        # Check interest alignment
        has_interest_match = any(
            (intr in res_topic or intr in res_title or res_topic in intr)
            for intr in student_interests
        )

        # Check level proximity
        levels = ["beginner", "intermediate", "advanced"]
        st_lvl = normalise_text(student.current_level)
        res_diff = normalise_text(item_row["difficulty"])

        dist = abs(levels.index(st_lvl) - levels.index(res_diff)) if (st_lvl in levels and res_diff in levels) else 1
        level_appropriate = (dist <= 1)

        return has_interest_match and level_appropriate

    def evaluate_cohort(self, k: int = 5, revision_mode: bool = False) -> Dict[str, Any]:
        """
        Evaluates Precision@K, Hit Rate@K, MRR, and Catalog Coverage across the student cohort.
        """
        precisions = []
        hits = []
        reciprocal_ranks = []
        recommended_resource_ids = set()
        exclusion_successes = []

        for _, s_row in self.students_df.iterrows():
            student = StudentProfile.from_dict(s_row.to_dict())
            recs = self.engine.recommend(student, top_n=k, revision_mode=revision_mode)

            # Record recommended IDs for coverage
            for rid in recs["resource_id"]:
                recommended_resource_ids.add(rid)

            # Check precision & reciprocal rank
            rel_count = 0
            first_rel_rank = 0

            for rank_idx, (_, item_row) in enumerate(recs.iterrows(), start=1):
                rel = self.is_item_relevant(student, item_row)
                if rel:
                    rel_count += 1
                    if first_rel_rank == 0:
                        first_rel_rank = rank_idx

            precision = rel_count / max(k, 1)
            precisions.append(precision)
            hits.append(1 if rel_count > 0 else 0)
            reciprocal_ranks.append(1.0 / first_rel_rank if first_rel_rank > 0 else 0.0)

            # Check completed topic exclusion rate
            if not revision_mode and student.completed_topics:
                # Count if any completed topic was mistakenly recommended
                violated = False
                for _, rec_row in recs.iterrows():
                    rec_topic = normalise_text(rec_row["topic"])
                    rec_title = normalise_text(rec_row["title"])
                    for comp in student.completed_topics:
                        c = normalise_text(comp)
                        if c and (c in rec_topic or c in rec_title):
                            violated = True
                            break
                    if violated:
                        break
                exclusion_successes.append(0 if violated else 1)

        total_catalog = len(self.resources_df)
        catalog_coverage = (len(recommended_resource_ids) / total_catalog) * 100.0 if total_catalog > 0 else 0.0
        completed_exclusion_rate = float(np.mean(exclusion_successes)) * 100.0 if exclusion_successes else 100.0

        results = {
            "cohort_size": len(self.students_df),
            "k": k,
            "mean_precision_at_k": float(np.mean(precisions)),
            "hit_rate_at_k": float(np.mean(hits)),
            "mean_reciprocal_rank": float(np.mean(reciprocal_ranks)),
            "catalog_coverage_pct": float(catalog_coverage),
            "unique_resources_recommended": len(recommended_resource_ids),
            "total_catalog_resources": total_catalog,
            "completed_topic_exclusion_rate_pct": completed_exclusion_rate,
        }
        return results


if __name__ == "__main__":
    evaluator = RecommenderEvaluator()
    print("Evaluating Recommender across all 50 student profiles (K=5)...")
    res = evaluator.evaluate_cohort(k=5, revision_mode=False)
    print("\n--- EVALUATION BENCHMARK RESULTS ---")
    print(f"  Cohort Size                    : {res['cohort_size']} students")
    print(f"  Top-K                          : {res['k']}")
    print(f"  Precision@{res['k']}                   : {res['mean_precision_at_k']:.4f} ({res['mean_precision_at_k']*100:.1f}%)")
    print(f"  Hit Rate@{res['k']} (HR@{res['k']})            : {res['hit_rate_at_k']:.4f} ({res['hit_rate_at_k']*100:.1f}%)")
    print(f"  Mean Reciprocal Rank (MRR)     : {res['mean_reciprocal_rank']:.4f}")
    print(f"  Catalog Coverage               : {res['catalog_coverage_pct']:.2f}% ({res['unique_resources_recommended']}/{res['total_catalog_resources']})")
    print(f"  Completed Exclusion Accuracy   : {res['completed_topic_exclusion_rate_pct']:.2f}%")
