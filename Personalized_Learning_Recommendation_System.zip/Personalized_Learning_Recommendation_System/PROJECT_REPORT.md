# Project Report: Personalized Learning Recommendation System

**Course:** Machine Learning (BCA57205)  
**Project Group:** GR-1  
**Project Title:** Personalized Learning Recommendation System  
**Development Environment:** Python 3.10+ using Visual Studio Code  

---

## 1. Project Title
**Personalized Learning Recommendation System (PLRS)**  
An Explainable Content-Based Educational Recommender System Utilizing TF-IDF Vectorization, Cosine Similarity, and Pedagogical Multi-Factor Re-Ranking.

---

## 2. Problem Statement
In self-directed and digital learning environments, students are often overwhelmed by the volume of available online educational resources. Conventional search engines return generic or popularity-biased results without considering a learner's:
1. Specific topical interests and stated goals,
2. Current proficiency level (Beginner, Intermediate, Advanced),
3. Preferred learning modality (Video, Hands-on exercises, Textual reading, Quizzes),
4. Prior academic performance and subject-specific learning gaps,
5. Time availability (weekly study hours), and
6. Topics previously completed and mastered.

Without personalized recommendations, students often attempt materials that are too difficult or redundant, leading to frustration, inefficient study habits, and lower learning retention.

---

## 3. Objectives
1. **Data Ingestion and Modeling:** Design and preprocess structured datasets capturing student academic profiles, study habits, and a curated catalog of learning resources.
2. **Feature Extraction:** Transform unstructured resource textual metadata (topics, titles, descriptions) into weighted TF-IDF numerical vectors.
3. **Semantic Similarity Calculation:** Compute cosine similarity between student stated interests and learning resource feature vectors.
4. **Pedagogical Multi-Factor Re-Ranking:** Combine textual relevance with difficulty appropriateness, modality match, academic weakness remediation, and weekly study hour constraints into a composite match score.
5. **Non-Redundancy & Revision Control:** Filter out topics already completed by the student while offering an optional revision mode for reinforcement.
6. **Explainable AI (XAI):** Generate human-interpretable pedagogical rationales explaining *why* each resource was selected.
7. **Exploratory Data Analysis (EDA):** Analyze distributions of academic marks, learning styles, and correlation between weekly study hours and student performance using Pandas, NumPy, and Matplotlib.
8. **Evaluation & Testing:** Measure recommendation quality using information retrieval metrics (Precision@K, Hit Rate@K, MRR, Catalog Coverage) and maintain an automated test suite.

---

## 4. Dataset Description and Source
The system utilizes two primary datasets stored in the `data/` directory:

### 4.1 Students Dataset (`students.csv`)
Contains 50 realistic, anonymized synthetic student records designed to represent an undergraduate computer science / BCA cohort.
- **`student_id`** *(Categorical / String)*: Unique identifier (e.g., `S001` to `S050`).
- **`name`** *(String)*: Student name.
- **`interests`** *(Text)*: Comma-separated domain interests (e.g., `"python, machine learning, data science"`).
- **`preferred_style`** *(Categorical)*: Learning format preference (`video`, `hands-on`, `reading`, `quiz`).
- **`current_level`** *(Categorical)*: Academic proficiency level (`beginner`, `intermediate`, `advanced`).
- **`math_score`** *(Float, 0.0 - 100.0)*: Prior performance in Mathematics / Statistics.
- **`programming_score`** *(Float, 0.0 - 100.0)*: Prior performance in Programming / Software Development.
- **`data_science_score`** *(Float, 0.0 - 100.0)*: Prior performance in Data Science / Databases.
- **`study_hours_per_week`** *(Float, 0.0 - 80.0)*: Self-reported weekly study hours.
- **`completed_topics`** *(Text)*: Semicolon-delimited list of concepts already mastered by the student.

*Dataset Provenance Note:* The dataset is synthetic and constructed to model realistic classroom distributions without exposing personally identifiable information (PII) or confidential institutional student records.

### 4.2 Learning Resources Dataset (`learning_resources.csv`)
Contains 26 curated educational resources spanning major computer science and data disciplines:
- **`resource_id`** *(String)*: Unique identifier (`R001` to `R026`).
- **`title`** *(String)*: Resource title.
- **`topic`** *(Categorical)*: Subject domain (e.g., `python`, `machine learning`, `data science`, `statistics`, `databases`, `web development`, `data visualization`, `mathematics`, `ai`).
- **`description`** *(Text)*: Summary of covered syllabus topics and learning outcomes.
- **`resource_type`** *(Categorical)*: Delivery format (`video`, `hands-on`, `reading`, `quiz`).
- **`difficulty`** *(Categorical)*: Cognitive difficulty level (`beginner`, `intermediate`, `advanced`).
- **`url`** *(String)*: Web URL for accessing the learning material.

---

## 5. Recommendation Algorithm

The system implements a **Content-Based Filtering** recommendation model augmented with a **Multi-Factor Pedagogical Ranking Function**:

### Step 1: Text Feature Vectorization
The catalog corpus is constructed by concatenating resource attributes:
$$\text{Corpus}_i = \text{Topic}_i \oplus \text{Title}_i \oplus \text{Description}_i$$
The student's interest query $Q$ is transformed alongside the corpus using Scikit-Learn's `TfidfVectorizer` (with unigrams and bigrams, English stop words removed):
$$\text{TF-IDF}(t, d) = \text{TF}(t, d) \times \log\left(\frac{1 + N}{1 + \text{DF}(t)}\right) + 1$$

### Step 2: Semantic Cosine Similarity
Cosine similarity between query vector $\vec{Q}$ and resource vector $\vec{D}_i$ is computed using NumPy:
$$S_{\text{text}}(Q, D_i) = \frac{\vec{Q} \cdot \vec{D}_i}{\|\vec{Q}\|_2 \|\vec{D}_i\|_2} \in [0, 1]$$

### Step 3: Difficulty Distance Calibration
The difficulty alignment score penalizes materials that diverge from the student's current proficiency:
$$S_{\text{diff}} = 
\begin{cases} 
1.00 & \text{if } |\text{index}(\text{level}_{\text{res}}) - \text{index}(\text{level}_{\text{stu}})| = 0 \\
0.60 & \text{if } |\text{index}(\text{level}_{\text{res}}) - \text{index}(\text{level}_{\text{stu}})| = 1 \\
0.20 & \text{if } |\text{index}(\text{level}_{\text{res}}) - \text{index}(\text{level}_{\text{stu}})| = 2 
\end{cases}$$

### Step 4: Modality Alignment
Scores delivery format preference:
$$S_{\text{style}} = 
\begin{cases} 
1.00 & \text{if } \text{resource\_type} = \text{preferred\_style} \\
0.35 & \text{otherwise}
\end{cases}$$

### Step 5: Academic Gap Reinforcement Boost
Identifies which subject area the resource supports and awards higher priority to subjects where the student's prior score is lower:
$$S_{\text{skill}} = \frac{100 - \text{Score}_{\text{domain}}}{100}$$

### Step 6: Study Hours Feasibility Boost
If a student reports limited study hours ($< 8$ hours/week), an additional feasibility bonus ($+0.05$) is awarded to bite-sized formats (`quiz` and `video`) to ensure realistic completion.

### Step 7: Composite Match Score Formula
$$\text{Match Score} = 0.55 \times S_{\text{text}} + 0.20 \times S_{\text{diff}} + 0.15 \times S_{\text{style}} + 0.10 \times S_{\text{skill}} + \text{Feasibility Boost}$$

### Step 8: Completed Topics Filtering & Ranking
If revision mode is disabled, resources whose topics or title keywords intersect with `completed_topics` are filtered out. The remaining candidates are sorted in descending order of `Match Score`, and the top-$K$ resources are selected.

---

## 6. Flowchart

```mermaid
flowchart TD
    A([Start: Student Initiates Application]) --> B[Load Datasets: students.csv & learning_resources.csv]
    B --> C[Input Student Information: Interests, Style, Level, Scores, Hours, Completed]
    C --> D[Validate Input Fields: 0 <= marks <= 100, hours >= 0]
    D -->|Validation Failed| E[Display Error Message & Prompt Again]
    E --> C
    D -->|Validation Passed| F[Instantiate StudentProfile Object]
    F --> G[TF-IDF Vectorization of Interests & Catalog Corpus]
    G --> H[Compute Cosine Similarity Array]
    H --> I[Compute Multi-Factor Pedagogical Scores: Level, Style, Skill Gap]
    I --> J[Calculate Composite Match Score]
    J --> K{Revision Mode Enabled?}
    K -->|No| L[Filter Out Completed Topics]
    K -->|Yes| M[Retain All Catalog Items]
    L --> N[Sort Resources by Match Score Descending]
    M --> N
    N --> O[Select Top-K Recommendations]
    O --> P[Generate Explainable Rationale for Each Item]
    P --> Q[Display Recommendations & Why Chosen]
    Q --> R{User Actions}
    R -->|Export| S[Save Formatted Report to outputs/recs.txt]
    R -->|EDA| T[Generate & Save Matplotlib Plots]
    R -->|Evaluate| U[Compute Precision@K, HR@K, MRR, Coverage]
    R -->|Exit| V([End Application])
```

---

## 7. Pseudocode

```text
ALGORITHM GeneratePersonalizedRecommendations:
INPUT:
    student_profile: StudentProfile (interests, style, level, scores, study_hours, completed_topics)
    catalog: List of LearningResource
    top_k: Integer (default 5)
    revision_mode: Boolean (default False)

OUTPUT:
    ranked_recommendations: List of (LearningResource, MatchScore, Explanation)

BEGIN
    // Step 1: Input Validation
    CALL student_profile.validate()
    
    // Step 2: TF-IDF & Cosine Similarity
    corpus <- [res.topic + " " + res.title + " " + res.description FOR res IN catalog]
    query <- student_profile.interests
    corpus.append(query)
    
    tfidf_matrix <- TfidfVectorizer.fit_transform(corpus)
    query_vector <- tfidf_matrix[last_row]
    catalog_vectors <- tfidf_matrix[0 TO last_row - 1]
    text_scores <- CosineSimilarity(query_vector, catalog_vectors)
    
    // Step 3: Multi-Factor Scoring
    FOR each index i, resource IN catalog:
        // Difficulty alignment
        level_dist <- ABS(Index(student_profile.level) - Index(resource.difficulty))
        IF level_dist == 0 THEN diff_score[i] <- 1.00
        ELSE IF level_dist == 1 THEN diff_score[i] <- 0.60
        ELSE diff_score[i] <- 0.20
        
        // Style alignment
        IF resource.type == student_profile.preferred_style THEN
            style_score[i] <- 1.00
        ELSE
            style_score[i] <- 0.35
            
        // Weak-subject reinforcement boost
        domain_score <- GetStudentDomainScore(student_profile, resource.topic)
        skill_boost[i] <- (100 - domain_score) / 100.0
        
        // Workload feasibility bonus
        feasibility_boost[i] <- 0.0
        IF student_profile.study_hours < 8.0 AND resource.type IN ['video', 'quiz'] THEN
            feasibility_boost[i] <- 0.05
            
        // Composite match score
        match_score[i] <- (0.55 * text_scores[i]) + 
                          (0.20 * diff_score[i]) + 
                          (0.15 * style_score[i]) + 
                          (0.10 * skill_boost[i]) + 
                          feasibility_boost[i]
    END FOR
    
    // Step 4: Completed Topics Filtering
    candidates <- []
    FOR each resource, score IN catalog, match_score:
        IF revision_mode == False AND resource.topic IN student_profile.completed_topics THEN
            CONTINUE // Skip mastered topic
        candidates.append((resource, score))
    END FOR
    
    // Step 5: Sorting & Ranking
    SORT candidates BY score DESCENDING
    top_candidates <- candidates.slice(0, top_k)
    
    // Step 6: Generate Explanations (XAI)
    FOR each resource, score IN top_candidates:
        explanation <- BuildPedagogicalExplanation(resource, student_profile, score)
        ranked_recommendations.append((resource, score, explanation))
    END FOR
    
    RETURN ranked_recommendations
END
```

---

## 8. System Design and Implementation
The project follows a modular, object-oriented software design:

- **`data_loader.py` (Data Access Layer):** Defines domain entity classes (`StudentProfile`, `LearningResource`) and `DataLoader` for robust CSV ingestion, missing value imputation, type casting, and schema enforcement.
- **`recommender.py` (Machine Learning Engine):** Encapsulates the `RecommendationEngine` class with TF-IDF vectorization, cosine similarity, multi-factor pedagogical scoring, completed topic filtering, and explanation generation.
- **`eda.py` (Exploratory Data Analysis Layer):** Implements `EDAVisualizer` using Pandas, NumPy, and Matplotlib to compute summary statistics and generate high-resolution visualization charts into `outputs/figures/`.
- **`evaluator.py` (Model Evaluation Layer):** Implements `RecommenderEvaluator` to measure offline information retrieval benchmarks (Precision@K, Hit Rate, MRR, Coverage).
- **`cli.py` & `main.py` (User Interface):** Provides an interactive console terminal interface with comprehensive input validation, error handling, report export, and menu-driven execution.
- **`app.py` (Streamlit Web Interface):** Interactive GUI offering web-based profile inspection, recommendations, and EDA visualization.
- **`tests/test_recommender.py` (Test Suite):** Unit test suite verifying boundary conditions, filtering, ranking order, and error handling.

---

## 9. Python Concepts Used
The implementation meaningfully demonstrates all mandatory Python curriculum concepts:

1. **Conditions (`if`, `elif`, `else`):** Used throughout profile validation (validating score bounds $0 \le s \le 100$ and study hours $0 \le h \le 80$), difficulty distance mapping, and revision mode toggling.
2. **Loops (`for`, `while`):** Employed in interactive CLI menu loops, corpus tokenization, candidate filtering, and metric calculation across the student cohort.
3. **Data Collections (Lists, Dicts, Tuples, Sets):**
   - Lists: Storing resource text sequences and candidate rows.
   - Dictionaries: Configuration parameters, composite scoring weights, and summary metrics.
   - Tuples: Immutable validation choices (`VALID_LEVELS`, `VALID_STYLES`).
   - Sets: Fast membership testing for completed topics exclusion and catalog coverage tracking.
4. **Functions & Type Annotations:** Modular functions equipped with type hints (`Optional`, `Dict`, `List`, `Union`) and docstrings.
5. **Sorting Algorithms:** Multi-key sorting in Python using `sort_values(by=[...], ascending=[...])` and Python's `sorted(..., key=lambda x: ...)` for ranking candidate resources.
6. **File Handling:** Reading and writing CSV datasets with `pandas.read_csv`, exporting recommendation reports to text files with context managers (`with open(...) as f:`), and exporting Matplotlib figures to PNG.
7. **Exception Handling:** Custom exception hierarchy (`RecommendationSystemError`, `InvalidStudentProfileError`, `DatasetLoadError`), `try/except/finally` blocks, preventing application crashes on malformed inputs.
8. **Classes and Objects (OOP):** Dataclasses (`StudentProfile`, `LearningResource`), encapsulation in `RecommendationEngine`, `DataLoader`, `EDAVisualizer`, and `RecommenderEvaluator`.
9. **NumPy:**
   - Multi-dimensional array operations (`np.ndarray`, `np.zeros`).
   - Vectorized metric computations (`np.mean`, `np.median`, `np.std`).
   - Correlation analysis (`np.corrcoef`) and polynomial regression (`np.polyfit`).
   - Matrix clipping (`np.clip`) and mathematical operations.
10. **Pandas:**
    - DataFrame transformations, indexing, boolean masking, and querying.
    - Missing value handling (`fillna`, `isna`) and data type coercion (`to_numeric`).
    - Cross-tabulation (`pd.crosstab`) and categorical frequency counts (`value_counts`).
11. **Matplotlib:**
    - Figure and subplot layout management (`plt.subplots`).
    - Histograms, scatter plots, trendlines, horizontal stacked bar charts, and annotations.
    - Publication-grade styling, custom color palettes, grid configurations, and DPI scaling.

---

## 10. Data Preprocessing and EDA

### Preprocessing Steps
1. **Deduplication:** Stripping duplicate records using unique identifiers (`student_id`, `resource_id`).
2. **String Normalization:** Trimming leading/trailing whitespace, converting text to lowercase, and standardizing delimiter formats (handling both semicolons and commas).
3. **Missing Value Imputation:** Imputing missing academic scores with baseline median scores (70.0) and missing study hours with 10.0 hrs/wk.
4. **Range Enforcement:** Restricting numeric values using `.clip(0.0, 100.0)` for marks and `.clip(0.0, 80.0)` for weekly study hours.

### Exploratory Data Analysis Summary (Cohort of 50 Students)
- **Academic Performance Across Subjects:**
  - Mathematics: Mean = $76.66$, Std = $9.73$, Median = $76.50$
  - Programming: Mean = $75.64$, Std = $9.75$, Median = $77.50$
  - Data Science: Mean = $73.88$, Std = $11.70$, Median = $74.00$
- **Study Hours Distribution:**
  - Weekly Study Hours: Mean = $14.88$ hrs/wk, Std = $4.75$ hrs/wk, Median = $14.50$ hrs/wk
- **Correlation Analysis:**
  - Pearson correlation coefficient between weekly study hours and average performance: **$r = 0.90$** (demonstrating strong positive correlation between consistent study hours and academic achievement).
- **Generated Visualization Charts (`outputs/figures/`):**
  1. `marks_distribution.png`: Histogram displaying distribution of scores across subjects with mean and median markers.
  2. `study_hours_vs_performance.png`: Scatter plot and linear fit trendline validating study hours vs academic performance.
  3. `learning_style_distribution.png`: Bar chart depicting preference across Video, Hands-on, Reading, and Quiz formats alongside proficiency level distributions.
  4. `resource_catalog_breakdown.png`: Stacked bar chart showing resource distribution by topic and difficulty level.
  5. `recommendation_score_breakdown.png`: Stacked horizontal bar chart illustrating component score contributions.

---

## 11. Recommendation Methodology
The recommendation engine uses an explainable, hybrid content-based methodology:
1. **Unsupervised Semantic Extraction:** Leverages Scikit-Learn's `TfidfVectorizer` to extract term frequency-inverse document frequency features from resource metadata and student queries.
2. **Cosine Angle Proximity:** Determines the mathematical angle between the student's interest vector and candidate resource vectors.
3. **Multi-Criteria Pedagogical Re-ranking:** Re-scores candidates by balancing topical similarity ($55\%$), difficulty appropriateness ($20\%$), format compatibility ($15\%$), and academic gap reinforcement ($10\%$).
4. **Non-Redundancy Guarantee:** Actively discards topics previously completed by the learner unless revision is requested.
5. **Transparent Explainability:** Deconstructs the final score into plain-language pedagogical rationale bullets.

---

## 12. Evaluation Methodology and Actual Results
To evaluate the recommender objectively without fabricated claims, an offline evaluation was conducted across all 50 student profiles in the dataset using standard information retrieval metrics.

### Evaluation Criteria:
An item is deemed relevant for a test student if:
1. Its topic or title intersects with the student's stated interests, and
2. Its difficulty level is within $\pm 1$ step of the student's current proficiency level.

### Benchmark Results (Top-$K = 5$):
| Metric | Value | Meaning / Interpretation |
| :--- | :---: | :--- |
| **Cohort Size** | 50 Students | Number of student profiles evaluated |
| **Top-$K$** | 5 | Number of recommendations displayed per student |
| **Mean Precision@5** | **0.5680 (56.8%)** | Over half of all recommended top-5 items directly match both student interests and difficulty level |
| **Hit Rate@5 (HR@5)** | **0.9800 (98.0%)** | 98% of students receive at least one highly relevant resource in their top 5 recommendations |
| **Mean Reciprocal Rank (MRR)** | **0.8757** | The first relevant resource appears on average at rank 1.14 (almost always the top recommendation) |
| **Catalog Coverage** | **100.00% (26/26)** | All 26 catalog resources are reachable across the student cohort, ensuring no dead catalog items |
| **Completed Exclusion Accuracy** | **100.00%** | Zero completed topics were recommended when revision mode was disabled |

---

## 13. System Screenshots Placeholders

Below are designated placeholders for project documentation screenshots:

### Screenshot 1: Interactive Terminal Menu
```text
+--------------------------------------------------------------------------+
| [PLACEHOLDER: CLI Main Menu]                                             |
| Capture terminal output showing options 1 to 4 and banner                |
+--------------------------------------------------------------------------+
```

### Screenshot 2: Recommendation Output with Explainable Rationale
```text
+--------------------------------------------------------------------------+
| [PLACEHOLDER: Personalized Recommendation Output]                        |
| Capture recommendations showing Title, Topic, Match Score, and           |
| "Why Chosen" explanation bullets                                         |
+--------------------------------------------------------------------------+
```

### Screenshot 3: Exploratory Data Analysis Plots
```text
+--------------------------------------------------------------------------+
| [PLACEHOLDER: Generated Charts in outputs/figures/]                      |
| Display marks_distribution.png and study_hours_vs_performance.png        |
+--------------------------------------------------------------------------+
```

### Screenshot 4: Automated Test Suite Execution
```text
+--------------------------------------------------------------------------+
| [PLACEHOLDER: Unit Tests Output]                                         |
| Terminal screenshot showing 17 tests passed (OK)                         |
+--------------------------------------------------------------------------+
```

---

## 14. Testing and Quality Assurance
An automated test suite comprising 17 unit tests was developed in `tests/test_recommender.py` using Python's `unittest` framework:

### Test Coverage Summary
- **Dataset Loading:**
  - `test_load_students_success`: Verifies student CSV loading and schema presence.
  - `test_load_resources_success`: Verifies resource catalog CSV loading and column presence.
  - `test_missing_dataset_file_raises_error`: Validates `DatasetLoadError` on invalid path.
- **Boundary Condition & Validation Tests:**
  - `test_valid_student_profile`: Verifies valid profile instantiation.
  - `test_negative_marks_raise_error`: Confirms rejection of marks $< 0$.
  - `test_marks_above_100_raise_error`: Confirms rejection of marks $> 100$.
  - `test_negative_study_hours_raise_error`: Confirms rejection of study hours $< 0$.
  - `test_excessive_study_hours_raise_error`: Confirms rejection of study hours $> 80$ hrs/wk.
  - `test_invalid_level_raise_error`: Confirms rejection of unsupported proficiency levels.
  - `test_invalid_style_raise_error`: Confirms rejection of unsupported learning styles.
- **Recommendation & Business Logic Tests:**
  - `test_recommendation_generation`: Verifies recommendation generation for standard profile.
  - `test_recommendation_ranking_order`: Verifies match scores are sorted in strict descending order.
  - `test_empty_interests_fallback`: Verifies graceful fallback when interest query is blank.
  - `test_completed_topics_excluded_when_not_revising`: Confirms completed topics are filtered out.
  - `test_completed_topics_included_when_revision_mode_enabled`: Confirms completed topics are included when revision mode is activated.
  - `test_explainability_reason_present`: Validates that each recommendation contains pedagogical explanations.
- **Evaluation Benchmark Tests:**
  - `test_evaluator_metrics`: Verifies Precision@K, Hit Rate, and MRR calculations.

**Execution Result:**
```
Ran 17 tests in 0.336s
OK
```

---

## 15. Limitations
1. **Catalog Size:** The prototype catalog consists of 26 curated resources. While adequate for academic demonstration, a production system would require hundreds of catalog items.
2. **Text Representation:** TF-IDF captures exact term and n-gram overlap but does not capture deep semantic synonyms (e.g., "neural net" vs "deep learning") that transformer-based dense embeddings (e.g., BERT/Sentence-Transformers) could resolve.
3. **Static Feedback:** Currently, the system uses an offline heuristics-based multi-factor formula. It does not yet incorporate real-time implicit student feedback (dwell time, clicks, course completion rates).

---

## 16. Individual Contribution Template
*(To be completed by group members according to teacher's submission guidelines)*

| Student Name | Roll Number / PRN | Assigned Module / Responsibility | Specific Contributions & Key Code Files |
| :--- | :--- | :--- | :--- |
| **[Student 1 Name]** | [Roll No] | Data Preprocessing & Modeling | Designed `data_loader.py`, schema validation, created synthetic dataset `students.csv`. |
| **[Student 2 Name]** | [Roll No] | Recommendation Engine & XAI | Implemented `recommender.py`, TF-IDF vectorization, composite ranking formula, explanations. |
| **[Student 3 Name]** | [Roll No] | EDA & Visualization | Implemented `eda.py`, generated Matplotlib distributions, correlation analysis. |
| **[Student 4 Name]** | [Roll No] | Evaluation, Testing & UI | Implemented `evaluator.py`, `tests/test_recommender.py`, CLI interface in `cli.py`. |

---

## 17. Conclusion
The Personalized Learning Recommendation System demonstrates a complete, transparent, and syllabus-aligned machine learning application for computer science education. By combining TF-IDF content similarity with pedagogical constraints (proficiency levels, format preferences, academic weakness targeting, and completed topics filtering), the system provides explainable recommendations that support individual learner journeys. The codebase satisfies all requirements of course **BCA57205 - Machine Learning**, featuring modular object-oriented Python, automated unit tests, and rigorous data analysis.

---

## 18. Setup and Execution Instructions

### Prerequisites
- Python 3.10, 3.11, 3.12, 3.13, or 3.14
- Visual Studio Code or any standard terminal

### Step 1: Install Dependencies
Open a terminal in the project directory and install the required packages:
```bash
pip install -r requirements.txt
```

### Step 2: Run the Main Application
From the project workspace root:
```bash
python main.py
```
This launches the interactive terminal interface menu.

### Step 3: Run Automated Tasks via Command Line
- **Generate EDA Visualization Charts:**
  ```bash
  python main.py --eda
  ```
- **Execute Recommendation Evaluation Benchmark:**
  ```bash
  python main.py --eval
  ```
- **Execute Quick Test:**
  ```bash
  python main.py --quick-test
  ```

### Step 4: Run the Automated Unit Test Suite
```bash
python -m unittest tests/test_recommender.py
```
