"""
data_loader.py
==============
Data loading, validation, and object modeling for the Personalized
Learning Recommendation System.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
import pandas as pd


class RecommendationSystemError(Exception):
    """Base exception for the recommendation system."""
    pass


class InvalidStudentProfileError(RecommendationSystemError):
    """Raised when student profile parameters fail validation."""
    pass


class DatasetLoadError(RecommendationSystemError):
    """Raised when dataset files cannot be loaded or have invalid schema."""
    pass


VALID_LEVELS = ("beginner", "intermediate", "advanced")
VALID_STYLES = ("video", "hands-on", "reading", "quiz")


@dataclass
class StudentProfile:
    """Represents an individual student's learning profile."""
    student_id: str
    name: str
    interests: str
    preferred_style: str = "video"
    current_level: str = "beginner"
    math_score: float = 70.0
    programming_score: float = 70.0
    data_science_score: float = 70.0
    study_hours_per_week: float = 10.0
    completed_topics: List[str] = field(default_factory=list)

    def __post_init__(self):
        # Normalize and validate inputs upon creation
        self.preferred_style = str(self.preferred_style).strip().lower()
        self.current_level = str(self.current_level).strip().lower()
        if isinstance(self.completed_topics, str):
            if self.completed_topics.strip():
                # Split on semicolon or comma
                raw_topics = [t.strip().lower() for t in self.completed_topics.replace(";", ",").split(",") if t.strip()]
                self.completed_topics = raw_topics
            else:
                self.completed_topics = []

    def validate(self) -> None:
        """
        Validate all student fields against business rules.
        Raises InvalidStudentProfileError if validation fails.
        """
        # Validate scores
        for score_name, score_val in [
            ("Math score", self.math_score),
            ("Programming score", self.programming_score),
            ("Data science score", self.data_science_score),
        ]:
            if not isinstance(score_val, (int, float)) or np.isnan(score_val):
                raise InvalidStudentProfileError(f"{score_name} must be a valid number.")
            if score_val < 0.0 or score_val > 100.0:
                raise InvalidStudentProfileError(f"{score_name} ({score_val}) must be between 0 and 100.")

        # Validate study hours
        if not isinstance(self.study_hours_per_week, (int, float)) or np.isnan(self.study_hours_per_week):
            raise InvalidStudentProfileError("Study hours must be a valid number.")
        if self.study_hours_per_week < 0.0:
            raise InvalidStudentProfileError(f"Study hours ({self.study_hours_per_week}) cannot be negative.")
        if self.study_hours_per_week > 80.0:
            raise InvalidStudentProfileError(f"Study hours ({self.study_hours_per_week}) exceeds realistic weekly limit (80h).")

        # Validate categorical levels
        if self.current_level not in VALID_LEVELS:
            raise InvalidStudentProfileError(
                f"Current level '{self.current_level}' is invalid. Allowed: {', '.join(VALID_LEVELS)}"
            )

        # Validate preferred style
        if self.preferred_style not in VALID_STYLES:
            raise InvalidStudentProfileError(
                f"Preferred style '{self.preferred_style}' is invalid. Allowed: {', '.join(VALID_STYLES)}"
            )

    @property
    def average_score(self) -> float:
        """Calculates the student's overall academic average score."""
        return float(np.mean([self.math_score, self.programming_score, self.data_science_score]))

    def to_dict(self) -> Dict[str, Any]:
        """Converts the profile to a dictionary."""
        return {
            "student_id": self.student_id,
            "name": self.name,
            "interests": self.interests,
            "preferred_style": self.preferred_style,
            "current_level": self.current_level,
            "math_score": self.math_score,
            "programming_score": self.programming_score,
            "data_science_score": self.data_science_score,
            "study_hours_per_week": self.study_hours_per_week,
            "completed_topics": ";".join(self.completed_topics),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StudentProfile":
        """Instantiates a StudentProfile from dictionary records."""
        completed = data.get("completed_topics", [])
        if isinstance(completed, str):
            completed = [t.strip().lower() for t in completed.replace(";", ",").split(",") if t.strip()]

        return cls(
            student_id=str(data.get("student_id", "NEW")),
            name=str(data.get("name", "Guest Student")),
            interests=str(data.get("interests", "")),
            preferred_style=str(data.get("preferred_style", "video")),
            current_level=str(data.get("current_level", "beginner")),
            math_score=float(data.get("math_score", 70.0)),
            programming_score=float(data.get("programming_score", 70.0)),
            data_science_score=float(data.get("data_science_score", 70.0)),
            study_hours_per_week=float(data.get("study_hours_per_week", 10.0)),
            completed_topics=completed,
        )


@dataclass
class LearningResource:
    """Represents a catalog learning item."""
    resource_id: str
    title: str
    topic: str
    description: str
    resource_type: str
    difficulty: str
    url: str

    def to_dict(self) -> Dict[str, str]:
        return {
            "resource_id": self.resource_id,
            "title": self.title,
            "topic": self.topic,
            "description": self.description,
            "resource_type": self.resource_type,
            "difficulty": self.difficulty,
            "url": self.url,
        }


class DataLoader:
    """
    Handles file loading, data cleaning, validation,
    and schema enforcement for students and resources datasets.
    """
    DEFAULT_DATA_DIR = Path(__file__).parent / "data"

    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = Path(data_dir) if data_dir else self.DEFAULT_DATA_DIR

    def load_students(self, filename: str = "students.csv") -> pd.DataFrame:
        """
        Loads and validates the student profiles dataset.
        Handles missing values and cleans formats.
        """
        file_path = self.data_dir / filename
        if not file_path.exists():
            raise DatasetLoadError(f"Students dataset file not found at: {file_path}")

        try:
            df = pd.read_csv(file_path)
        except Exception as e:
            raise DatasetLoadError(f"Error reading students CSV: {e}") from e

        required_cols = [
            "student_id", "name", "interests", "preferred_style",
            "current_level", "math_score", "programming_score",
            "data_science_score", "study_hours_per_week", "completed_topics"
        ]
        missing_cols = [c for c in required_cols if c not in df.columns]
        if missing_cols:
            raise DatasetLoadError(f"Students CSV missing required columns: {missing_cols}")

        # Drop duplicates on student_id
        df = df.drop_duplicates(subset=["student_id"]).copy()

        # Clean strings
        df["student_id"] = df["student_id"].astype(str).str.strip()
        df["name"] = df["name"].astype(str).str.strip()
        df["interests"] = df["interests"].fillna("").astype(str).str.strip()
        df["preferred_style"] = df["preferred_style"].fillna("video").astype(str).str.strip().str.lower()
        df["current_level"] = df["current_level"].fillna("beginner").astype(str).str.strip().str.lower()
        df["completed_topics"] = df["completed_topics"].fillna("").astype(str).str.strip()

        # Handle numeric values and impute missing if any
        for col in ["math_score", "programming_score", "data_science_score"]:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(70.0).clip(0.0, 100.0)

        df["study_hours_per_week"] = pd.to_numeric(df["study_hours_per_week"], errors="coerce").fillna(10.0).clip(0.0, 80.0)

        return df

    def load_resources(self, filename: str = "learning_resources.csv") -> pd.DataFrame:
        """
        Loads and validates the learning resources catalog.
        """
        file_path = self.data_dir / filename
        if not file_path.exists():
            raise DatasetLoadError(f"Learning resources file not found at: {file_path}")

        try:
            df = pd.read_csv(file_path)
        except Exception as e:
            raise DatasetLoadError(f"Error reading learning resources CSV: {e}") from e

        required_cols = ["resource_id", "title", "topic", "description", "resource_type", "difficulty", "url"]
        missing_cols = [c for c in required_cols if c not in df.columns]
        if missing_cols:
            raise DatasetLoadError(f"Learning resources CSV missing required columns: {missing_cols}")

        df = df.drop_duplicates(subset=["resource_id"]).copy()
        for col in required_cols:
            df[col] = df[col].fillna("").astype(str).str.strip()

        df["resource_type"] = df["resource_type"].str.lower()
        df["difficulty"] = df["difficulty"].str.lower()
        df["topic"] = df["topic"].str.lower()

        return df


